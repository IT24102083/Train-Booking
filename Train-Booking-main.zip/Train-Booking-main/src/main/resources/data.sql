
CREATE DATABASE train_booking;
USE train_booking;

-- Main User Table
CREATE TABLE users (
id BIGINT AUTO_INCREMENT PRIMARY KEY,
username VARCHAR(255) NOT NULL UNIQUE,
email VARCHAR(255) NOT NULL UNIQUE,
password VARCHAR(255) NOT NULL,
role VARCHAR(255) NOT NULL
);

-- Train Information
CREATE TABLE trains (
id BIGINT AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(255),
capacity INT NOT NULL
);

-- Train Schedules
CREATE TABLE schedules (
id BIGINT AUTO_INCREMENT PRIMARY KEY,
origin VARCHAR(255),
destination VARCHAR(255),
departure_time DATETIME,
arrival_time DATETIME,
fare DECIMAL(19, 2),
train_id BIGINT NOT NULL,
FOREIGN KEY (train_id) REFERENCES trains(id)
);

-- User Bookings
CREATE TABLE bookings (
id BIGINT AUTO_INCREMENT PRIMARY KEY,
booking_time DATETIME,
status VARCHAR(255),
passenger_id BIGINT NOT NULL,
schedule_id BIGINT NOT NULL,
FOREIGN KEY (passenger_id) REFERENCES users(id),
FOREIGN KEY (schedule_id) REFERENCES schedules(id)
);

-- Passenger Feedback
CREATE TABLE passenger_feedback (
feedback_id BIGINT AUTO_INCREMENT PRIMARY KEY,
message TEXT,
response TEXT,
status VARCHAR(255),
submitted_at DATETIME,
updated_at DATETIME,
passenger_id BIGINT NOT NULL,
ticket_id BIGINT,
updated_by BIGINT,
FOREIGN KEY (passenger_id) REFERENCES users(id),
FOREIGN KEY (ticket_id) REFERENCES bookings(id),
FOREIGN KEY (updated_by) REFERENCES users(id)
);

-- System Alerts
CREATE TABLE alerts (
id BIGINT AUTO_INCREMENT PRIMARY KEY,
message TEXT,
posted_at DATETIME,
posted_by BIGINT NOT NULL,
FOREIGN KEY (posted_by) REFERENCES users(id)
);

-- Insert sample users
-- Password for both is 'password' (stored in plain text as requested)
INSERT INTO users (username, email, password, role) VALUES ('passenger', 'passenger@example.com', 'password', 'PASSENGER');
INSERT INTO users (username, email, password, role) VALUES ('manager', 'manager@example.com', 'password', 'STATION_MANAGER');
INSERT INTO users (username, email, password, role) VALUES ('analyst', 'analyst@example.com', 'pass123', 'ANALYST');
INSERT INTO users (username, email, password, role) VALUES ('admin', 'admin@example.com', 'password', 'ADMIN_MANAGER');

-- Insert sample trains
INSERT INTO trains (name, capacity) VALUES ('Udarata Menike', 500);
INSERT INTO trains (name, capacity) VALUES ('Podi Menike', 450);
INSERT INTO trains (name, capacity) VALUES ('Yal Devi', 600);
INSERT INTO trains (name, capacity) VALUES ('Ruhunu Kumari', 550);

-- Insert sample schedules
-- Note: The train_id corresponds to the auto-incremented ID of the trains inserted above.
-- Udarata Menike (train_id = 1)
INSERT INTO schedules (train_id, origin, destination, departure_time, arrival_time, fare) VALUES (1, 'Colombo Fort', 'Badulla', '2025-09-10 05:55:00', '2025-09-10 15:50:00', 12.50);
INSERT INTO schedules (train_id, origin, destination, departure_time, arrival_time, fare) VALUES (1, 'Badulla', 'Colombo Fort', '2025-09-11 05:50:00', '2025-09-11 15:27:00', 12.50);

-- Podi Menike (train_id = 2)
INSERT INTO schedules (train_id, origin, destination, departure_time, arrival_time, fare) VALUES (2, 'Colombo Fort', 'Badulla', '2025-09-10 08:30:00', '2025-09-10 17:50:00', 11.75);

-- Yal Devi (train_id = 3)
INSERT INTO schedules (train_id, origin, destination, departure_time, arrival_time, fare) VALUES (3, 'Mount Lavinia', 'Kankesanthurai', '2025-09-10 05:10:00', '2025-09-10 13:38:00', 15.00);

-- Ruhunu Kumari (train_id = 4)
INSERT INTO schedules (train_id, origin, destination, departure_time, arrival_time, fare) VALUES (4, 'Maradana', 'Matara', '2025-09-10 14:25:00', '2025-09-10 17:40:00', 8.00);
