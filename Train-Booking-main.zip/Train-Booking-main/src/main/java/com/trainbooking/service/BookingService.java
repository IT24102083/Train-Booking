package com.trainbooking.service;

import com.trainbooking.model.Booking;
import com.trainbooking.model.Schedule;
import com.trainbooking.model.User;
import com.trainbooking.repository.BookingRepository;
import com.trainbooking.repository.ScheduleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private ScheduleRepository scheduleRepository;

    @Transactional
    public Booking createBooking(User passenger, Long scheduleId) {
        Schedule schedule = scheduleRepository.findById(scheduleId)
                .orElseThrow(() -> new IllegalArgumentException("Schedule not found with ID: " + scheduleId));

        // In a real application, you would check schedule availability/capacity here.

        Booking booking = new Booking();
        booking.setPassenger(passenger);
        booking.setSchedule(schedule);
        booking.setBookingTime(LocalDateTime.now());
        booking.setStatus("CONFIRMED");

        return bookingRepository.save(booking);
    }

    public List<Booking> findBookingsForUser(User passenger) {
        return bookingRepository.findByPassenger(passenger);
    }

    public Booking findById(Long bookingId) {
        return bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid booking Id:" + bookingId));
    }

    @Transactional
    public void cancelBooking(Long bookingId, User passenger) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid booking Id:" + bookingId));

        if (!booking.getPassenger().getId().equals(passenger.getId())) {
            throw new IllegalStateException("You are not authorized to cancel this booking.");
        }

        if ("CANCELLED".equals(booking.getStatus())) {
            throw new IllegalStateException("Booking is already cancelled.");
        }

        booking.setStatus("CANCELLED");
        bookingRepository.save(booking);
    }
}
