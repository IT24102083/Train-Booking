package com.trainbooking.service;

import com.trainbooking.model.Train;
import com.trainbooking.repository.TrainRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TrainService {

    @Autowired
    private TrainRepository trainRepository;

    public List<Train> findAll() {
        return trainRepository.findAll();
    }

    public Train findById(Long id) {
        return trainRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid train Id:" + id));
    }

    public void save(Train train) {
        trainRepository.save(train);
    }

    public void delete(Long id) {
        trainRepository.deleteById(id);
    }
}
