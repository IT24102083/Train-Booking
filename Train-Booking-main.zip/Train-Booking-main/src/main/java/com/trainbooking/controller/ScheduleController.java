package com.trainbooking.controller;

import com.trainbooking.model.Schedule;
import com.trainbooking.service.ScheduleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class ScheduleController {

    @Autowired
    private ScheduleService scheduleService;

    @GetMapping("/schedules")
    public String viewSchedules(@RequestParam(value = "origin", required = false) String origin,
                                @RequestParam(value = "destination", required = false) String destination,
                                Model model) {
        List<Schedule> scheduleList;
        if (origin != null && !origin.isBlank() && destination != null && !destination.isBlank()) {
            scheduleList = scheduleService.searchSchedules(origin, destination);
        } else {
            scheduleList = scheduleService.findAllSchedules();
        }
        model.addAttribute("schedules", scheduleList);
        model.addAttribute("origin", origin);
        model.addAttribute("destination", destination);
        return "schedules";
    }
}
