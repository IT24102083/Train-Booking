package com.trainbooking.controller;

import com.trainbooking.model.PassengerFeedback;
import com.trainbooking.model.User;
import com.trainbooking.service.PassengerFeedbackService;
import com.trainbooking.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/feedback")
public class FeedbackController {

    @Autowired
    private PassengerFeedbackService feedbackService;

    @Autowired
    private UserService userService;

    @GetMapping("/new")
    public String showFeedbackForm(Model model) {
        model.addAttribute("feedback", new PassengerFeedback());
        return "feedback/form";
    }

    @PostMapping("/submit")
    public String submitFeedback(@ModelAttribute("feedback") PassengerFeedback feedback, Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }
        User user = userService.findByUsername(principal.getName());
        feedbackService.saveFeedback(feedback, user);
        return "redirect:/feedback/my-feedback";
    }

    @GetMapping("/my-feedback")
    public String viewMyFeedback(Model model, Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }
        User user = userService.findByUsername(principal.getName());
        List<PassengerFeedback> feedbackList = feedbackService.findFeedbackByPassenger(user);
        model.addAttribute("feedbackList", feedbackList);
        return "feedback/history";
    }
}
