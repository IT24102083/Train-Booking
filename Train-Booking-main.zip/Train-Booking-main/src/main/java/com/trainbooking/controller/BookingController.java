package com.trainbooking.controller;

import com.trainbooking.model.Booking;
import com.trainbooking.model.User;
import com.trainbooking.service.BookingService;
import com.trainbooking.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/bookings")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    @Autowired
    private UserService userService;

    @PostMapping("/create/{scheduleId}")
    public String createBooking(@PathVariable Long scheduleId, Principal principal, RedirectAttributes redirectAttributes) {
        if (principal == null) {
            return "redirect:/login";
        }
        User user = userService.findByUsername(principal.getName());
        try {
            bookingService.createBooking(user, scheduleId);
            redirectAttributes.addFlashAttribute("successMessage", "Booking successful!");
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            return "redirect:/schedules";
        }
        return "redirect:/bookings/my-bookings";
    }

    @GetMapping("/my-bookings")
    public String viewMyBookings(Model model, Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }
        User user = userService.findByUsername(principal.getName());
        List<Booking> bookingList = bookingService.findBookingsForUser(user);
        model.addAttribute("bookings", bookingList);
        return "my-bookings";
    }

    @PostMapping("/cancel/{bookingId}")
    public String cancelBooking(@PathVariable Long bookingId, Principal principal, RedirectAttributes redirectAttributes) {
        if (principal == null) {
            return "redirect:/login";
        }
        try {
            User user = userService.findByUsername(principal.getName());
            bookingService.cancelBooking(bookingId, user);
            redirectAttributes.addFlashAttribute("successMessage", "Booking successfully cancelled.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/bookings/my-bookings";
    }

    @GetMapping("/ticket/{bookingId}")
    public String viewTicket(@PathVariable Long bookingId, Model model, Principal principal, RedirectAttributes redirectAttributes) {
        if (principal == null) {
            return "redirect:/login";
        }
        try {
            Booking booking = bookingService.findById(bookingId);
            User user = userService.findByUsername(principal.getName());

            if (!booking.getPassenger().getId().equals(user.getId())) {
                redirectAttributes.addFlashAttribute("errorMessage", "You are not authorized to view this ticket.");
                return "redirect:/bookings/my-bookings";
            }

            model.addAttribute("booking", booking);
            return "ticket";
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Ticket not found.");
            return "redirect:/bookings/my-bookings";
        }
    }
}
