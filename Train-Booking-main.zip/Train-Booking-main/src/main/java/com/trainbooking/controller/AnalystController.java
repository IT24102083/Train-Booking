package com.trainbooking.controller;

import com.trainbooking.model.PassengerFeedback;
import com.trainbooking.model.User;
import com.trainbooking.service.PassengerFeedbackService;
import com.trainbooking.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/analyst/feedback")
public class AnalystController {

    @Autowired
    private PassengerFeedbackService feedbackService;

    @Autowired
    private UserService userService;

    @GetMapping
    public String listAllFeedback(Model model) {
        List<PassengerFeedback> feedbackList = feedbackService.findAll();
        model.addAttribute("feedbackList", feedbackList);
        return "analyst/feedback-list";
    }

    @PostMapping("/update/{id}")
    public String updateFeedbackStatus(@PathVariable Long id, @RequestParam String status, @RequestParam String response, Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }
        User analyst = userService.findByUsername(principal.getName());
        feedbackService.updateStatus(id, status, response, analyst);
        return "redirect:/analyst/feedback";
    }

    @PostMapping("/delete/{feedbackId}")
    public String deleteFeedback(@PathVariable Long feedbackId, RedirectAttributes redirectAttributes) {
        try {
            feedbackService.deleteFeedback(feedbackId);
            redirectAttributes.addFlashAttribute("successMessage", "Feedback successfully deleted.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/analyst/feedback";
    }
}
