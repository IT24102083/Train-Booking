package com.trainbooking.controller;

import com.trainbooking.model.Train;
import com.trainbooking.service.TrainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin/trains")
public class TrainManagementController {

    @Autowired
    private TrainService trainService;

    @GetMapping
    public String listTrains(Model model) {
        List<Train> trainList = trainService.findAll();
        model.addAttribute("trains", trainList);
        return "admin/trains/list";
    }

    @GetMapping("/new")
    public String showCreateForm(Model model) {
        model.addAttribute("train", new Train());
        return "admin/trains/form";
    }

    @GetMapping("/edit/{id}")
    public String showUpdateForm(@PathVariable("id") Long id, Model model) {
        Train train = trainService.findById(id);
        model.addAttribute("train", train);
        return "admin/trains/form";
    }

    @PostMapping("/save")
    public String saveTrain(@ModelAttribute("train") Train train) {
        trainService.save(train);
        return "redirect:/admin/trains";
    }

    @PostMapping("/delete/{id}")
    public String deleteTrain(@PathVariable("id") Long id) {
        trainService.delete(id);
        return "redirect:/admin/trains";
    }
}
