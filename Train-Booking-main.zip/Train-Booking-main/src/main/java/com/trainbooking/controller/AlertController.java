package com.trainbooking.controller;

import com.trainbooking.model.Alert;
import com.trainbooking.model.User;
import com.trainbooking.service.AlertService;
import com.trainbooking.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.security.Principal;
import java.util.List;

@Controller
public class AlertController {

    @Autowired
    private AlertService alertService;

    @Autowired
    private UserService userService;

    // Public endpoint to view all alerts
    @GetMapping("/alerts")
    public String viewAllAlerts(Model model) {
        List<Alert> alertList = alertService.findAllSorted();
        model.addAttribute("alerts", alertList);
        return "alerts";
    }

    // Admin endpoint to show the form for creating a new alert
    @GetMapping("/admin/alerts/new")
    public String showAlertForm(Model model) {
        model.addAttribute("alert", new Alert());
        return "admin/alert-form";
    }

    // Admin endpoint to handle the creation of a new alert
    @PostMapping("/admin/alerts/create")
    public String createAlert(@ModelAttribute("alert") Alert alert, Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }
        User admin = userService.findByUsername(principal.getName());
        alertService.createAlert(alert, admin);
        return "redirect:/alerts";
    }
}
