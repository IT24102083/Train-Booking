package com.trainbooking.controller;

import com.trainbooking.model.User;
import com.trainbooking.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public String processRegistration(@ModelAttribute User user) {
        // Set a default role for new users
        user.setRole("PASSENGER");
        userService.registerUser(user);
        return "redirect:/login?success";
    }
}
