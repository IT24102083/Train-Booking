# 🚆 Web-Based Train Scheduling & Booking System

## 📌 Project Overview
This system is a comprehensive web application designed to digitize and optimize the Sri Lankan railway experience. It offers a seamless interface for passengers to search for trains, book tickets, and provide feedback. It also empowers various administrative roles with tools for real-time schedule updates, user management, and system maintenance.

---

## ✨ Features

### 👤 Passenger Features
- **User Authentication**: Secure registration and login for all users.
- **Schedule Viewing**: View a list of all available train schedules.
- **Schedule Search**: Filter schedules by origin and destination.
- **Ticket Booking**: Book tickets for a chosen schedule.
- **View Bookings**: View a history of all personal bookings.
- **Cancel Booking**: Cancel any active ('CONFIRMED') booking.
- **E-Ticket Viewing**: View a printable E-Ticket with a unique QR code for each confirmed booking.
- **Feedback Submission**: Submit complaints or questions to the system administrators.
- **View Feedback**: View personal submission history and see responses from an analyst.
- **View Alerts**: View system-wide alerts and notifications posted by administrators.

### 👮 Station Manager Features
- **Schedule Management**: Full CRUD (Create, Read, Update, Delete) capabilities for train schedules.
- **Train Management**: Full CRUD capabilities for the trains themselves (e.g., add a new train to the fleet).
- **Post Alerts**: Post system-wide alerts for all users to see.

### 🕵️ Passenger Experience Analyst Features
- **View All Feedback**: View a list of all feedback submitted by all passengers.
- **Manage Feedback**: Update the status of feedback (e.g., 'New' -> 'In Review' -> 'Resolved').
- **Respond to Feedback**: Write and submit a response to a passenger's feedback.
- **Delete Resolved Feedback**: Delete feedback items once they have been resolved.

### 👑 Admin Manager Features
- **User Management**: Full CRUD capabilities for all user accounts, including the ability to change user roles and delete users.

---

## 🛠️ Tech Stack
- **Backend**: Java 11, Spring Boot 2.7.5, Spring MVC, Spring Data JPA, Spring Security
- **Build Tool**: Maven
- **Database**: MySQL
- **Frontend**: HTML5, CSS3, JavaScript
- **Templating Engine**: Thymeleaf
- **UI Frameworks**: Bootstrap 5, Animate.css

---

## 🚀 Getting Started

### Prerequisites
- Java JDK 11 or higher
- Apache Maven
- A running MySQL server

### 1. Database Setup
Create a new database in MySQL named `train_booking`.
```sql
CREATE DATABASE train_booking;
USE train_booking;
```
The application uses `spring.jpa.hibernate.ddl-auto=update`, so Hibernate will automatically create the necessary tables when the application starts for the first time. Alternatively, you can use the following SQL script to create the full schema manually:

```sql
-- Main User Table
CREATE TABLE users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(255) NOT NULL
);

-- Train Information
CREATE TABLE trains (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    capacity INT NOT NULL
);

-- Train Schedules
CREATE TABLE schedules (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    origin VARCHAR(255),
    destination VARCHAR(255),
    departure_time DATETIME,
    arrival_time DATETIME,
    fare DECIMAL(19, 2),
    train_id BIGINT NOT NULL,
    FOREIGN KEY (train_id) REFERENCES trains(id)
);

-- User Bookings
CREATE TABLE bookings (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    booking_time DATETIME,
    status VARCHAR(255),
    passenger_id BIGINT NOT NULL,
    schedule_id BIGINT NOT NULL,
    FOREIGN KEY (passenger_id) REFERENCES users(id),
    FOREIGN KEY (schedule_id) REFERENCES schedules(id)
);

-- Passenger Feedback
CREATE TABLE passenger_feedback (
    feedback_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    message TEXT,
    response TEXT,
    status VARCHAR(255),
    submitted_at DATETIME,
    updated_at DATETIME,
    passenger_id BIGINT NOT NULL,
    ticket_id BIGINT,
    updated_by BIGINT,
    FOREIGN KEY (passenger_id) REFERENCES users(id),
    FOREIGN KEY (ticket_id) REFERENCES bookings(id),
    FOREIGN KEY (updated_by) REFERENCES users(id)
);

-- System Alerts
CREATE TABLE alerts (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    message TEXT,
    posted_at DATETIME,
    posted_by BIGINT NOT NULL,
    FOREIGN KEY (posted_by) REFERENCES users(id)
);
```

### 2. Application Configuration
Open the `src/main/resources/application.properties` file and ensure the database connection details match your local MySQL setup:
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/train_booking?useSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=password
```
Change `root` and `password` to your MySQL username and password.

### 3. Running the Application
The project is configured with sample data in `src/main/resources/data.sql` which will be inserted on startup.

You can run the application using the Spring Boot Maven plugin:
```bash
mvn spring-boot:run
```
The application will be available at `http://localhost:8080`.

---

## 👥 Sample User Accounts

The following user accounts are created by default from the `data.sql` file. Note that passwords are saved as plain text per project requirements.

| Username         | Password  | Role                |
|------------------|-----------|---------------------|
| `passenger`      | `password`| PASSENGER           |
| `manager`        | `password`| STATION_MANAGER     |
| `analyst`        | `pass123` | ANALYST             |
| `admin`          | `password`| ADMIN_MANAGER       |
