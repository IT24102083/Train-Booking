# Project Architecture Notes

## Authentication vs. Authorization

This document explains the authentication and authorization strategy used in this project.

### Authentication: Session-Based

This project uses **session-based authentication**, which is the traditional and standard mechanism for server-side rendered applications built with Spring Boot and Thymeleaf. It does **not** use JWTs.

**How it works:**
1.  **Login:** A user submits their credentials via the login form.
2.  **Verification:** Spring Security validates these credentials against the database using our `CustomUserDetailsService`.
3.  **Session Creation:** Upon success, the server creates a session in its memory and associates it with the authenticated user.
4.  **Cookie:** The server sends a unique session ID (e.g., `JSESSIONID`) to the user's browser, which stores it as a cookie.
5.  **Subsequent Requests:** The browser automatically sends this cookie with every follow-up request. The server uses the ID to retrieve the user's session, confirming they are authenticated.

This is a **stateful** approach, as the server must maintain session state for all active users. This is in contrast to a **stateless** JWT approach, where the server does not store session data and instead validates a self-contained token sent by the client on each request.

### Authorization: Role-Based Access Control (RBAC)

Authorization (controlling what a user is allowed to do) is handled via roles.

**How it works:**
1.  **Roles:** Each user in the `users` table has a `role` (e.g., `PASSENGER`, `STATION_MANAGER`, `ANALYST`, `ADMIN_MANAGER`).
2.  **Configuration:** The `SecurityConfig.java` file defines rules that map URL patterns to required roles. For example:
    ```java
    .antMatchers("/admin/users/**").hasRole("ADMIN_MANAGER")
    .antMatchers("/admin/**").hasRole("STATION_MANAGER")
    .antMatchers("/analyst/**").hasRole("ANALYST")
    ```
3.  **Enforcement:**
    *   **Backend:** Spring Security automatically enforces these rules for every incoming request. If a user tries to access a page without the required role, they will be denied.
    *   **Frontend:** The Thymeleaf templates use the `sec:authorize="hasRole('...')"` attribute to conditionally show or hide links and buttons, ensuring users only see the options available to them.
